"""Image Promotion Backend - API REST para CRUD de usuários."""
