from typing import Optional
from uuid import UUID

from src.domain import (
    User,
    UserPersistencePort,
    UserNotFoundException,
    UserAlreadyExistsException,
)


class UserService:
    """Serviço de aplicação para operações com usuários (use cases)."""

    def __init__(self, persistence_port: UserPersistencePort):
        self._persistence = persistence_port

    def create_user(self, name: str, email: str) -> User:
        """Cria um novo usuário.

        Args:
            name: Nome do usuário
            email: Email do usuário

        Returns:
            User: Usuário criado

        Raises:
            UserAlreadyExistsException: Se já existir usuário com o email
        """
        existing_user = self._persistence.find_by_email(email)
        if existing_user:
            raise UserAlreadyExistsException(email)

        user = User(name=name, email=email)
        return self._persistence.save(user)

    def get_user(self, user_id: UUID) -> User:
        """Busca um usuário pelo ID.

        Args:
            user_id: ID do usuário

        Returns:
            User: Usuário encontrado

        Raises:
            UserNotFoundException: Se o usuário não existir
        """
        user = self._persistence.find_by_id(user_id)
        if not user:
            raise UserNotFoundException(str(user_id))
        return user

    def get_user_by_email(self, email: str) -> User:
        """Busca um usuário pelo email.

        Args:
            email: Email do usuário

        Returns:
            User: Usuário encontrado

        Raises:
            UserNotFoundException: Se o usuário não existir
        """
        user = self._persistence.find_by_email(email)
        if not user:
            raise UserNotFoundException(email)
        return user

    def list_users(self, skip: int = 0, limit: int = 100) -> list[User]:
        """Lista todos os usuários com paginação.

        Args:
            skip: Quantidade de registros para pular
            limit: Quantidade máxima de registros

        Returns:
            list[User]: Lista de usuários
        """
        return self._persistence.find_all(skip=skip, limit=limit)

    def update_user(
        self, user_id: UUID, name: Optional[str] = None, email: Optional[str] = None
    ) -> User:
        """Atualiza um usuário existente.

        Args:
            user_id: ID do usuário
            name: Novo nome (opcional)
            email: Novo email (opcional)

        Returns:
            User: Usuário atualizado

        Raises:
            UserNotFoundException: Se o usuário não existir
            UserAlreadyExistsException: Se o novo email já estiver em uso
        """
        user = self._persistence.find_by_id(user_id)
        if not user:
            raise UserNotFoundException(str(user_id))

        if email and email != user.email:
            existing_user = self._persistence.find_by_email(email)
            if existing_user:
                raise UserAlreadyExistsException(email)

        user.update(name=name, email=email)
        return self._persistence.update(user)

    def delete_user(self, user_id: UUID) -> bool:
        """Remove um usuário.

        Args:
            user_id: ID do usuário

        Returns:
            bool: True se removido com sucesso

        Raises:
            UserNotFoundException: Se o usuário não existir
        """
        user = self._persistence.find_by_id(user_id)
        if not user:
            raise UserNotFoundException(str(user_id))

        return self._persistence.delete(user_id)
